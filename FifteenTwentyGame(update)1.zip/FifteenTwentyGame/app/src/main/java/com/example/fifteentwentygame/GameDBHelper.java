package com.example.fifteentwentygame;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.concurrent.atomic.AtomicInteger;

public class GameDBHelper extends SQLiteOpenHelper {
    public static final String COLUMN_OPPONENT = "opponent";
    public static final String COLUMN_RESULT = "result";
    public static final String COLUMN_ROUNDS = "rounds";
    private static final int DATABASE_VERSION = 3;
    private static final String DATABASE_NAME = "GameRecords.db";
    private static GameDBHelper instance;
    private final AtomicInteger openCounter = new AtomicInteger();
    private SQLiteDatabase database;

    public static synchronized GameDBHelper getInstance(Context context) {
        if (instance == null) {
            instance = new GameDBHelper(context.getApplicationContext());
        }
        return instance;
    }

    GameDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE game_logs (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "timestamp INTEGER NOT NULL," +
                "opponent TEXT NOT NULL," +
                "result TEXT NOT NULL," +
                "rounds INTEGER NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS game_logs");
        onCreate(db);
    }

    public synchronized SQLiteDatabase openDatabase() {
        if (openCounter.incrementAndGet() == 1) {
            database = getWritableDatabase();
        }
        return database;
    }

    public synchronized void closeDatabase() {
        if (openCounter.decrementAndGet() == 0) {
            database.close();
        }
    }

    public long addGameRecord(String opponent, String result, int rounds) {
        ContentValues values = new ContentValues();
        values.put("timestamp", System.currentTimeMillis());
        values.put("opponent", opponent);
        values.put("result", result);
        values.put("rounds", rounds);

        try {
            return database.insert("game_logs", null, values);
        } catch (Exception e) {
            return -1;
        }
    }

    public Cursor getAllRecords() {
        return database.query("game_logs",
                new String[]{"_id", "timestamp", "opponent", "result", "rounds"},
                null, null, null, null,
                "timestamp DESC");
    }

    public int getWinCount() {
        return getResultCount("Win");
    }

    public int getLossCount() {
        return getResultCount("Lost");
    }

    private int getResultCount(String result) {
        try (Cursor cursor = database.rawQuery(
                "SELECT COUNT(*) FROM game_logs WHERE result = ?",
                new String[]{result})) {
            return cursor.moveToFirst() ? cursor.getInt(0) : 0;
        }
    }
}