package com.example.fifteentwentygame;

import android.content.Context;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class GameAPIClient {
    private static final String BASE_URL = "https://assign-mobileasignment-ihudikcgrf.cn-hongkong.fcapp.run";
    private final Executor executor = Executors.newSingleThreadExecutor();

    public interface GameCallback {
        void onSuccess(int left, int right, int guess);
        void onError(String error);
    }

    public void getOpponentMove(Context context, GameCallback callback) {
        executor.execute(() -> {
            HttpURLConnection connection = null;
            try {
                URL url = new URL(BASE_URL);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(3000);
                connection.setReadTimeout(3000);

                try (InputStream is = connection.getInputStream();
                     BufferedReader reader = new BufferedReader(new InputStreamReader(is))) {
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }

                    JSONObject json = new JSONObject(response.toString());
                    int left = json.getInt("left");
                    int right = json.getInt("right");
                    int guess = json.getInt("guess");

                    ((android.app.Activity) context).runOnUiThread(() ->
                            callback.onSuccess(left, right, guess));
                }
            } catch (Exception e) {
                ((android.app.Activity) context).runOnUiThread(() ->
                        callback.onError(e.getMessage()));
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
        });
    }
}