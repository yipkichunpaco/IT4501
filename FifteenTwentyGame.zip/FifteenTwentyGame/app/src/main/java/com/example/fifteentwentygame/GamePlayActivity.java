package com.example.fifteentwentygame;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class GamePlayActivity extends AppCompatActivity {
    private GameDBHelper dbHelper;
    private GameAPIClient apiClient;
    private String opponent;
    private int round = 1;
    private boolean isPlayerTurn = true;
    private int playerLeft = 0, playerRight = 0, playerGuess = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_play);

        dbHelper = GameDBHelper.getInstance(this);
        apiClient = new GameAPIClient();
        opponent = getIntent().getStringExtra("opponent");

        setupUI();
        startRound();
    }

    private void setupUI() {
        updateRoundText();

        Button btnSubmit = findViewById(R.id.btnSubmit);
        btnSubmit.setOnClickListener(v -> submitMove());

        findViewById(R.id.btnNextRound).setOnClickListener(v -> nextRound());
        findViewById(R.id.btnFinishGame).setOnClickListener(v -> finishGame());
    }

    private void startRound() {
        clearSelections();
        if (!isPlayerTurn) {
            fetchOpponentMove();
        }
    }

    private void submitMove() {
        if (!validateSelection()) return;

        playerLeft = getSelectedValue(R.id.rgLeftHand);
        playerRight = getSelectedValue(R.id.rgRightHand);
        playerGuess = getSelectedValue(R.id.rgGuess);

        if (isPlayerTurn) {
            fetchOpponentMove();
        } else {
            checkRoundResult();
        }
    }

    private void checkRoundResult() {
    }

    private void fetchOpponentMove() {
        apiClient.getOpponentMove(this, new GameAPIClient.GameCallback() {
            @Override
            public void onSuccess(int left, int right, int guess) {
                runOnUiThread(() -> processOpponentMove(left, right, guess));
            }

            @Override
            public void onError(String error) {
                runOnUiThread(() -> {
                    Toast.makeText(GamePlayActivity.this,
                            "Using random opponent move", Toast.LENGTH_SHORT).show();
                    processOpponentMove(
                            (int) (Math.random() * 3) * 5,
                            (int) (Math.random() * 3) * 5,
                            5 + (int) (Math.random() * 4) * 5
                    );
                });
            }
        });
    }

    private void processOpponentMove(int left, int right, int guess) {
        int opponentTotal = left + right;
        int playerTotal = playerLeft + playerRight;

        if (isPlayerTurn) {
            checkPlayerGuess(playerTotal, opponentTotal);
        } else {
            checkOpponentGuess(guess, playerTotal, opponentTotal);
        }
    }

    private void checkPlayerGuess(int playerTotal, int opponentTotal) {
        boolean correct = playerGuess == (playerTotal + opponentTotal);
        showResult(correct, playerGuess, playerTotal, opponentTotal);
    }

    private void checkOpponentGuess(int guess, int playerTotal, int opponentTotal) {
        boolean correct = guess == (playerTotal + opponentTotal);
        showResult(!correct, guess, playerTotal, opponentTotal);
    }

    private void showResult(boolean win, int guess, int playerTotal, int opponentTotal) {
        TextView tvResult = findViewById(R.id.tvResult);
        Button btnNext = findViewById(R.id.btnNextRound);
        Button btnFinish = findViewById(R.id.btnFinishGame);

        @SuppressLint("DefaultLocale") String resultText = String.format("%s\nYour hands: %d + %d = %d\nOpponent hands: %d + %d = %d\nTotal: %d",
                win ? "You win!" : "You lose!",
                playerLeft, playerRight, playerTotal,
                playerLeft, playerRight, opponentTotal,
                playerTotal + opponentTotal);

        tvResult.setText(resultText);
        tvResult.setVisibility(View.VISIBLE);

        if (round < 3) {
            btnNext.setVisibility(View.VISIBLE);
        } else {
            btnFinish.setVisibility(View.VISIBLE);
            recordGameResult(win);
        }
    }

    private void nextRound() {
        round++;
        isPlayerTurn = !isPlayerTurn;
        startRound();
        updateRoundText();
        clearResultUI();
    }

    private void finishGame() {
        finish();
    }

    private void recordGameResult(boolean win) {
        dbHelper.addGameRecord(opponent, win ? "Win" : "Lost", round);
    }

    // Helper methods
    @SuppressLint("DefaultLocale")
    private void updateRoundText() {
        ((TextView) findViewById(R.id.tvRound)).setText(
                String.format("Round %d vs %s (%s turn)",
                        round, opponent, isPlayerTurn ? "Your" : opponent + "'s"));
    }

    private void clearSelections() {
        ((RadioGroup) findViewById(R.id.rgLeftHand)).clearCheck();
        ((RadioGroup) findViewById(R.id.rgRightHand)).clearCheck();
        ((RadioGroup) findViewById(R.id.rgGuess)).clearCheck();
    }

    private void clearResultUI() {
        findViewById(R.id.tvResult).setVisibility(View.GONE);
        findViewById(R.id.btnNextRound).setVisibility(View.GONE);
        findViewById(R.id.btnFinishGame).setVisibility(View.GONE);
    }

    private boolean validateSelection() {
        // Check if all selections are made
        return true; // Implement proper validation
    }

    private int getSelectedValue(int radioGroupId) {
        // Get selected value from radio groups
        return 0; // Implement proper value extraction
    }

    @Override
    protected void onDestroy() {
        dbHelper.closeDatabase();
        super.onDestroy();
    }
}