package com.example.fifteentwentygame;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnPlay = findViewById(R.id.btnPlay);
        Button btnRecords = findViewById(R.id.btnRecords);
        Button btnClose = findViewById(R.id.btnClose);

        btnPlay.setOnClickListener(v ->
                startActivity(new Intent(this, OpponentSelectionActivity.class)));

        btnRecords.setOnClickListener(v ->
                startActivity(new Intent(this, RecordsActivity.class)));

        btnClose.setOnClickListener(v -> finish());
    }
}