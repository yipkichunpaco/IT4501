package com.example.fifteentwentygame;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class OpponentSelectionActivity extends AppCompatActivity {

    private static final String[] OPPONENTS = {"Alan", "May", "Sam", "Jenny", "Tom"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_opponent_selection);

        ListView listView = findViewById(R.id.opponentListView);
        listView.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                OPPONENTS));

        listView.setOnItemClickListener((parent, view, position, id) -> {
            Intent intent = new Intent(this, GamePlayActivity.class);
            intent.putExtra("opponent", OPPONENTS[position]);
            startActivity(intent);
        });
    }
}