package com.example.fifteentwentygame;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

public class RecordsActivity extends AppCompatActivity {
    private GameDBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_records);

        dbHelper = GameDBHelper.getInstance(this);
        dbHelper.openDatabase();
        displayRecords();
    }

    @SuppressLint("DefaultLocale")
    private void displayRecords() {
        Cursor cursor = dbHelper.getAllRecords();

        SimpleCursorAdapter adapter = getSimpleCursorAdapter(cursor);

        ListView listView = findViewById(R.id.recordsListView);
        listView.setAdapter(adapter);

        // Display stats
        TextView tvStats = findViewById(R.id.tvStats);
        tvStats.setText(String.format("Wins: %d | Losses: %d",
                dbHelper.getWinCount(),
                dbHelper.getLossCount()));
    }

    @NonNull
    private SimpleCursorAdapter getSimpleCursorAdapter(Cursor cursor) {
        String[] fromColumns = {
                GameDBHelper.COLUMN_OPPONENT,
                GameDBHelper.COLUMN_RESULT,
                GameDBHelper.COLUMN_ROUNDS
        };

        int[] toViews = {
                R.id.tvOpponent,
                R.id.tvResult,
                R.id.tvRounds
        };

        return  new SimpleCursorAdapter(
                this,
                R.layout.item_record,
                cursor,
                fromColumns,
                toViews,
                0
        );
    }

    @Override
    protected void onDestroy() {
        dbHelper.closeDatabase();
        super.onDestroy();
    }
}